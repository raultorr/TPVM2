
public class Main {
	/**
	 * @author Ra�l Torrijos Santos
	 * @author Mishell Janina Tigse Ortiz
	 * @param args
	 *            Command line parameters
	 */
	public static void main(String[] args) {
		Engine engine = new Engine();
		engine.start();
	}
}
